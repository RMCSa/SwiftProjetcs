import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'monitor_details.dart';
import '../services/api_service.dart';

class MonitorListScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: FutureBuilder(
        future: ApiService.getMonitors(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || snapshot.data?.isEmpty == true) {
            return Center(child: Text("Erro ao carregar dados"));
          }

          var monitors = snapshot.data;
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                // Caixa estilizada para o título
                Container(
                  padding:
                      EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0),
                  decoration: BoxDecoration(
                    color: Colors.blueAccent, // Cor de fundo da caixa
                    borderRadius:
                        BorderRadius.circular(15.0), // Borda arredondada
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.3),
                        blurRadius: 5.0,
                        offset: Offset(0, 2), // Sombra sutil
                      ),
                    ],
                  ),
                  child: Text(
                    "Monitores do DPD",
                    style: TextStyle(
                      fontSize: 24.0,
                      fontWeight: FontWeight.bold,
                      color: Colors.white, // Cor do texto
                    ),
                  ),
                ),
                SizedBox(
                    height: 20.0), // Espaçamento entre o título e o carrossel
                CarouselSlider.builder(
                  itemCount: monitors?.length ?? 0,
                  itemBuilder: (context, index, realIndex) {
                    var monitor = monitors?[index];
                    return GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) =>
                                MonitorDetailsScreen(monitorId: monitor['id']),
                          ),
                        );
                      },
                      child: SizedBox(
                        width: 300.0, // Largura fixa do card
                        height: 500.0, // Altura fixa do card
                        child: Card(
                          color: Colors.blue.shade100, // Cor de fundo do card
                          margin: EdgeInsets.symmetric(vertical: 15.0),
                          child: Padding(
                            padding: const EdgeInsets.all(10.0),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SizedBox(
                                  width: 100.0, // Largura fixa do avatar
                                  height: 100.0, // Altura fixa do avatar
                                  child: CircleAvatar(
                                    backgroundColor: Colors.blue,
                                    backgroundImage: NetworkImage(
                                        monitor['avatar']), // Imagem do avatar
                                  ),
                                ),
                                SizedBox(height: 10.0),
                                SizedBox(
                                  width: 200.0, // Largura fixa do texto
                                  child: Text(
                                    monitor['name'],
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      fontSize: 16.0,
                                      fontWeight: FontWeight.bold,
                                    ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                  options: CarouselOptions(
                    height: 500.0, // Altura total do carrossel
                    enlargeCenterPage: false,
                    autoPlay: false, // Desativa a rolagem automática
                    enableInfiniteScroll: true,
                    viewportFraction:
                        0.3, // Proporção do tamanho do item visível na tela
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
