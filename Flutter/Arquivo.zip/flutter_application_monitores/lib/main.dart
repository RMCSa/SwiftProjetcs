import 'package:flutter/material.dart';
import 'screens/monitor_list.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    title: "Monitores DPD",
    home: MonitorListScreen(),
  ));
}
