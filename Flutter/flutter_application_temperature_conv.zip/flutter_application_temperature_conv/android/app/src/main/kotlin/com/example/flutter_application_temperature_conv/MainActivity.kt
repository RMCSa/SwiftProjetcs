package com.example.flutter_application_temperature_conv

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
